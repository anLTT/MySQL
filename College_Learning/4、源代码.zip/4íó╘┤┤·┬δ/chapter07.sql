/*7.1.2事务的基本操作  */
# 查询员工表emp中陈二和李四当前的信息
SELECT * FROM emp WHERE ename='陈二' OR ename='李四';

# 开启事务
START TRANSACTION;

#将员工表emp中陈二和李四的奖金都设置为1000
UPDATE emp SET comm=10000 WHERE ename='陈二';
UPDATE emp SET comm=10000 WHERE ename='李四';

# 提交修改信息之前，查询员工表emp中陈二和李四当前的信息
SELECT * FROM emp WHERE ename='陈二' OR ename='李四';

# 回滚事务
ROLLBACK;

# 重新设置李四和陈二的奖金
设置陈二的奖金
UPDATE emp SET comm=1000 WHERE ename='陈二';

# 设置李四的奖金
UPDATE emp SET comm=1000 WHERE ename='李四';

# 提交事务
COMMIT;

/*多学一招：事务的自动提交  */
#开启事务自动提交
SELECT @@AUTOCOMMIT;

#查看当前会话的AUTOCOMMIT值
SELECT @@AUTOCOMMIT;

/*7.1.3事务的保存点  */
# 员工表emp中陈二和李四当前的奖金信息
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

#开启事务后，将陈二的奖金增加200，李四的奖金减少200
START TRANSACTION; -- 开启事务
UPDATE emp SET comm=comm+200 WHERE ename='陈二'; -- 设置陈二的奖金
UPDATE emp SET comm=comm-200 WHERE ename='李四'; -- 设置李四的奖金
SAVEPOINT  s1; -- 创建保存点s1

# 查询员工表emp中陈二和李四当前的奖金信息
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 将陈二的奖金修改为600，李四的奖金修改为1400
UPDATE emp SET comm=600 WHERE ename='陈二'; -- 设置陈二的奖金
UPDATE emp SET comm=1400 WHERE ename='李四'; -- 设置李四的奖金

# 回滚到保存点s1
ROLLBACK TO SAVEPOINT s1; 
# 回滚到保存点s1后，查询员工表emp中陈二和李四当前的奖金信息
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 回滚事务
ROLLBACK; 
# 回滚事务后，查询员工表emp中陈二和李四当前的奖金信息
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

/*7.2.1READ UNCOMMITTED  */
# 在客户端B将事务的隔离级别设置为READ UNCOMMITTED（读未提交）
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
# 查询事务的隔离级别
SELECT @@session.transaction_isolation;

# 查询陈二和李四当前的奖金信息
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 在客户端A中开启事务
START TRANSACTION;

# 对陈二和李四的奖金进行修改
UPDATE emp SET comm=comm-200 WHERE ename='陈二';
UPDATE emp SET comm=comm+200 WHERE ename='李四';

# 在客户端B中查询陈二和李四的奖金信息
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';
# 客户端A中进行事务回滚
ROLLBACK;

# 在客户端B中将事务的隔离级别设置为READ COMMITTED（读已提交）
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;

# 在客户端B中查询陈二和李四的奖金信息
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 客户端A中开启事务，并修改陈二和李四的奖金
START TRANSACTION;
UPDATE emp SET comm=comm-200 WHERE ename='陈二';
UPDATE emp SET comm=comm+200 WHERE ename='李四';

# 在客户端B中查询陈二和李四的奖金信息
 SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 客户端A中进行事务回滚
ROLLBACK;

/*7.2.2READ COMMITTED  */
# 在客户端B中，开启事务，查看陈二和李四当前的奖金信息
START TRANSACTION; -- 开启事务
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 客户端A中使用UPDATE语句修改陈二和李四的奖金信息
UPDATE emp SET comm=comm-200 WHERE ename='陈二';
UPDATE emp SET comm=comm+200 WHERE ename='李四';

# 客户端B中再次查询陈二和李四的奖金信息
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 客户端B中将事务的隔离级别设置为REPEATABLE READ（可重复读）
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

# 在客户端B中开启事务，并且对陈二和李四的奖金信息进行了查询
START TRANSACTION; -- 开启事务
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 在客户端A中使用UPDATE语句修改陈二和李四的奖金信息
UPDATE emp SET comm=comm-200 WHERE ename='陈二';
UPDATE emp SET comm=comm+200 WHERE ename='李四';

# 客户端B中对陈二和李四的奖金信息进行查询
SELECT ename,comm FROM emp WHERE ename='陈二' OR ename='李四';

# 客户端A中进行事务回滚
ROLLBACK;

/*7.2.3REPEATABLE READ  */
# 将客户端B的事务隔离级别设置为READ COMMITTED
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;

# 在客户端B中开启事务，并且查询奖金大于1500的员工信息
START TRANSACTION;
SELECT ename,comm FROM emp WHERE comm>1500;

# 在客户端A中插入员工信息
 INSERT INTO emp VALUES(9999,'悟空','人事',9982,3000,1800,40);

# 客户端B中再次查询奖金大于1500的员工信息
 SELECT ename,comm FROM emp WHERE comm>1500;


# 在客户端A中提交事务
COMMIT;

# 将客户端B中的隔离级别设置为REPEATABLE READ
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;

# 在客户端B中开启一个事务，并且查询奖金大于1500的员工信息
START TRANSACTION;
SELECT ename,comm FROM emp WHERE comm>1500;

# 在客户端A中执行添加操作
INSERT INTO emp VALUES(9977,'唐僧','人事',9982,4000,1900,40);

# 在客户端B中再次查询奖金大于1500的员工信息
SELECT ename,comm FROM emp WHERE comm>1500;

# 在客户端A中提交事务
COMMIT;

/*7.2.4SERIALIZABLE  */
# 客户端B中的隔离级别设置为SERIALIZABLE
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;

# 在客户端B中开启事务，然后使用SELECT语句查询奖金大于1500的员工信息
START TRANSACTION;
SELECT ename,comm FROM emp WHERE comm>1500;

# 在客户端A中往数据表emp中插入数据
INSERT INTO emp VALUES(9933,'沙僧','人事',9982,2000,1600,40);


/*7.3上机实践：图书管理系统中事务的应用  */
# 手动开启事务，首先删除原有图书信息，然后插入图书信息
START TRANSACTION;
DELETE FROM book;
INSERT INTO book (name,price,upload_time,borrower_id,borrow_time,state)
VALUES
('Java基础入门',59.00,CURRENT_TIMESTAMP,NULL,NULL,0),
('三国演义',69.00,CURRENT_TIMESTAMP,NULL,NULL,0),
('MySQL数据库入门',40.00,CURRENT_TIMESTAMP,1,'2021-08-06 11:16:05',1),
('JavaWeb程序开发入门',49.00,CURRENT_TIMESTAMP,NULL,NULL,0),
('西游记',59.00,CURRENT_TIMESTAMP,NULL,NULL,0),
('水浒传',66.66,CURRENT_TIMESTAMP,NULL,NULL,0),
('唐诗三百首',39.00,CURRENT_TIMESTAMP,NULL,NULL,0),
('Python数据可视化',49.80,CURRENT_TIMESTAMP,NULL,NULL,0);

# 查看操作后数据库的图书信息,然后提交事务
SELECT * FROM book;
COMMIT;