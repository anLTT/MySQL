/*6.1.2索引的创建  */
# 创建数据表dept_index时，创建单列的普通索引、唯一性索引、主键索引、全文索引和空间索引
CREATE TABLE dept_index(
	id INT,
	deptno  INT ,
	dname   VARCHAR(20),
	introduction VARCHAR(200),
	address GEOMETRY NOT NULL SRID 4326,
	PRIMARY KEY(id),        -- 创建主键索引
	UNIQUE INDEX (deptno),  -- 创建唯一性索引
	INDEX (dname),          -- 创建普通索引
	FULLTEXT (introduction),-- 创建全文索引
	SPATIAL INDEX (address) -- 创建空间索引
) ;

# 查看创建数据表index_normal的语句
SHOW CREATE TABLE dept_index\G

# 创建数据表index_multi，在数据表中的id和name字段上建立索引名为multi的普通索引
CREATE TABLE index_multi(
  id INT NOT NULL,
  name VARCHAR(20) NOT NULL,
  score FLOAT,
  INDEX multi(id,name)
);

# 查看数据表index_multi的创建信息
SHOW CREATE TABLE index_multi\G

# 创建新数据表dept_index02
CREATE TABLE dept_index02(
	id INT,
	deptno  INT ,
	dname   VARCHAR(20),
	introduction VARCHAR(200)
);	

# 在数据表dept_index02中的id字段上，建立一个名称为unique_id的唯一性索引
CREATE UNIQUE INDEX unique_id ON dept_index02(id);

# 查看数据表book的创建信息
SHOW CREATE TABLE dept_index02\G

# 在dept_index02表中的deptno字段和dname字段上，创建一个名称为multi_index的复合索引
CREATE INDEX multi_index ON dept_index02(deptno,dname);

# 查看数据表dept_index02的创建信息
SHOW CREATE TABLE dept_index02\G

# 创建数据表dept_index03
CREATE TABLE dept_index03(
	id INT,
	deptno  INT ,
	dname   VARCHAR(20)
) ;
# 在数据表dept_index03中的id字段上，创建名称为index_id的唯一性索引
ALTER TABLE dept_index03 ADD UNIQUE INDEX index_id(id);

# 查看数据表dept_index03的创建信息
SHOW CREATE TABLE dept_index03\G

# 在dept_index03表中的deptno字段和dname字段上，创建一个名称为multi_index的复合唯一性索引
ALTER TABLE dept_index03 ADD UNIQUE INDEX multi_index(deptno,dname);

# 查看数据表dept_index03的创建信息
SHOW CREATE TABLE dept_index03\G

/*6.1.3索引的查看  */
# 查看数据表dept_index 中的索引
SHOW INDEX FROM dept_index \G

# 往数据表dept_index中插入数据
INSERT INTO dept_index VALUES  
(1,'10','总裁办','决定公司发展的部门',ST_GeometryFromText('point(88 34)',4326)),
(2,'20','研究院','研发公司核心产品的部门',ST_GeometryFromText('point(88 34)',4326));

# 查询数据表dept_index中id为1的部门信息为例分析语句的执行情况
EXPLAIN SELECT id FROM ems.dept_index WHERE id=1 \G

/*6.1.4索引的删除  */
# 查看数据表dept_index的建表语句
SHOW CREATE TABLE dept_index \G

# 删除索引introduction
ALTER TABLE dept_index DROP INDEX introduction;

# 删除数据表dept_index中名称为dname的索引
DROP INDEX dname ON dept_index;

# 查看数据表dept_index的建表语句
SHOW CREATE TABLE dept_index \G

/*6.2.2视图管理 */
# 根据员工表中员工工号empno、员工姓名ename、职位job和部门编号deptno的数据创建视图view_emp
CREATE VIEW view_emp AS SELECT empno,ename,job,deptno FROM emp;

# 查看view_emp视图的数据
SELECT * FROM view_emp;

# 根据员工表中员工工号empno、员工姓名ename、职位job和部门编号deptno的数据创建视图view_emp，视图的字段名称和基本表不一致

CREATE VIEW view_emp2 (e_no,e_name,e_job,e_deptno)
 AS
SELECT empno,ename,job,deptno FROM emp;

# 查看view_emp2视图
SELECT * FROM view_emp2;

# 根据员工编号empno、员工姓名ename、职位job、部门编号deptno和部门名称dname的信息创建视图
CREATE VIEW view_emp_dept(e_no,e_name,e_job,e_deptno,e_deptname)
AS
SELECT e.empno,e.ename,e.job,e.deptno,d.dname FROM emp e LEFT JOIN dept d ON e.deptno=d.deptno;

# 查看view_emp_dept视图
SELECT * FROM view_emp_dept;

# 查看视图view_emp_dept的字段信息
DESCRIBE view_emp_dept;

# 使用SHOW TABLE STATUS语句查看视图view_emp_dept的信息

SHOW TABLE STATUS LIKE 'view_emp_dept' \G

# 使用SHOW CREATE VIEW语句查看视图view_emp_dept的信息
SHOW CREATE VIEW view_emp_dept\G

使用DESC语句查看view_emp_dept视图的信息
DESC view_emp_dept;

# 在view_emp_dept视图上新增一个员工表的mgr字段的信息
CREATE OR REPLACE VIEW view_emp_dept(e_no,e_name,e_job,e_mgr,e_deptno,e_deptname)
AS
SELECT e.empno,e.ename,e.job,e.mgr,e.deptno,d.dname FROM emp e LEFT JOIN dept d ON e.deptno=d.deptno;

# 查询视图view_emp中的数据
SELECT * FROM view_emp_dept;

# 将视图view_emp_dept中的部门编号字段进行删除
ALTER VIEW view_emp_dept (e_no,e_name,e_job,e_mgr,e_deptname)
AS
SELECT e.empno,e.ename,e.job,e.mgr,d.dname FROM emp e LEFT JOIN dept d ON e.deptno=d.deptno;

# 查询视图view_emp_dept中的数据
SELECT * FROM view_emp_dept;

# 删除视图view_emp
DROP VIEW view_emp;

/*6.2.3视图数据操作 */
创建部门表dept对应的视图
CREATE VIEW view_dept(d_no,d_name) AS SELECT * FROM dept;

# 通过视图view_dept向数据表dept中添加数据
INSERT INTO view_dept VALUES(50, '人力资源部');

# 通过视图将研究院的部门名称修改为研究中心
UPDATE view_dept SET d_name='研究中心' WHERE d_name='研究院';

# 通过视图view_dept删除部门表dept中部门名称为人力资源部的记录
DELETE FROM view_dept WHERE d_name='人力资源部';

/*6.3上机实践：图书管理系统中索引和视图的应用 */
# 在图书表book的图书名称name上创建一个索引index_bookname
ALTER TABLE book ADD INDEX index_bookname(name);

# 在图书名称name和图书状态state上建立一个索引index_bookname_state
ALTER TABLE book ADD INDEX index_bookname_state(name(20),state(1));

# 删除索引index_bookname_state
ALTER TABLE book DROP INDEX index_bookname_state;

# 创建一个只包含图书名称、图书上架时间和图书状态的视图view_book_state
CREATE VIEW view_book_state (图书名称,上架时间,状态) AS SELECT name,upload_time,state FROM book;

# 创建一个只包含图书名称、借阅者名称和借阅时间的视图view_book_borrower
CREATE VIEW view_book_borrower (图书名称,借阅者,借阅时间)
AS
SELECT b.name,u.name,borrow_time FROM book b,user u WHERE b.borrower_id=u.id;

# 删除视图view_book_borrower
DROP VIEW view_book_borrower;