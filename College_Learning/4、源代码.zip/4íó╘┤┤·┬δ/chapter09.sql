/*9.1.1数据的备份  */
# 使用mysqldump命令将数据库ems的数据备份在D盘backup的文件夹下，备份的文件名称为ems_20210610.sql
D:\Program Files>mysqldump -uroot -p123456 ems>D:/backup/ems_20210610.sql

/*9.1.2数据的还原  */
# 创建数据库emp_backup
CREATE DATABASE ems_backup;

# 使用mysql命令还原D:/backup目录下的ems_20210610.sql文件中的数据
mysql -uroot -p123456 ems_backup <D:/backup/ems_20210610.sql

# 查询数据库ems_backup下员工表emp中的数据
SELECT * FROM emp;

# 使用source命令还原D:/backup目录下的ems_20210610.sql文件中的数据
source D:/backup/ems_20210610.sql

/*9.2.2创建用户  */
# 使用CREATE USER语句创建2个新用户，用户名分别为test1和test2、密码分别为123和456
CREATE USER 'test1'@'localhost' IDENTIFIED BY '123','test2'@'localhost' IDENTIFIED BY '456';

# 查询mysql.user表中用户test1的数据
SELECT host,user,authentication_string ,plugin FROM mysql.user WHERE user='test1'\G

/*多学一招：使用GRANT语句创建用户  */
# 基于MySQL 5.7.33版本，使用GRANT语句创建一个新用户，用户名为test3、密码为789，并授予该用户对数据库ems中的员工表emp有查询权限
GRANT SELECT ON ems.emp TO 'test3'@'localhost' IDENTIFIED BY '789';

# 查询mysql.user表中用户test3的数据
SELECT host,user,authentication_string ,plugin FROM mysql.user WHERE user='test3'\G

/*9.2.3删除用户  */
# 用DROP USER语句删除用户test1
DROP USER 'test1'@'localhost';

# 使用DELETE语句删除用户test2
DELETE FROM mysql.user WHERE Host='localhost' AND User='test2';

/*9.2.4修改用户密码  */
# 使用root用户连接数据库后创建普通用户ems_test
CREATE USER 'ems_test'@'localhost' IDENTIFIED BY '123';

# 使用mysqladmin命令修改ems_test用户密码，新密码为456
mysqladmin -u ems_test -p password 456

# 用ALTER USER语句修改用户ems_test的密码，新密码为789
ALTER USER 'ems_test'@'localhost' IDENTIFIED BY '789';

# 使用SET语句修改用户ems_test的密码，新密码为8910
SET PASSWORD='8910';

/*多学一招：如何解决root用户密码丢失  */

# 使用--skip-grant-tables登录MySQL服务
mysqld --shared-memory --skip-grant-tables

# 重新打开一个命令行窗口，在新打开的窗口中登录MySQL服务器
mysql -u root
# 使用命令重新加载权限表
FLUSH PRIVILEGES;

# 使用ALTER USER语句设置root用户密码，新密码为123456
ALTER USER 'root'@'localhost' IDENTIFIED BY '123456';

/*9.3.2授予权限  */
# 对emp_test用户授予数据库ems的员工表emp的SELECT权限，以及对empno和ename字段的插入权限
GRANT SELECT,INSERT(empno,ename) ON ems.emp TO 'ems_test'@'localhost';

/*9.3.3查看权限  */
# 查看用户ems_test的授予表级权限
SELECT db,table_name,table_priv,column_priv FROM mysql.tables_priv WHERE user='ems_test';

# 查看用户ems_test的授予列级权限
SELECT db,table_name,column_name,column_priv FROM mysql.columns_priv WHERE user='ems_test';

# 使用SHOW GRANTS语句查看用户ems_test的权限信息
SHOW GRANTS FOR 'ems_test'@'localhost';

/*9.3.4收回权限  */
#对ems_test用户在ems.emp表中字段empno和ename的INSERT权限进行收回
REVOKE INSERT(empno,ename) ON ems.emp FROM 'ems_test'@'localhost';

# 从mysql.columns_priv中查看ems_test用户的列权限
SELECT db,table_name,column_name,column_priv FROM mysql.columns_priv WHERE user='ems_test';

# 收回用户ems_test的所有权限
REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'ems_test'@'localhost';

# 使用SHOW GRANTS语句查看用户ems_test的权限信息
SHOW GRANTS FOR 'ems_test'@'localhost';

/*9.4上机实践：图书管理系统数据库的管理  */
# 对bms数据库中的所有数据进行备份,备份到D盘backup文件夹下的bms_20210528.sql
mysqldump -uroot -p123456 bms>D:/backup/bms_20210528.sql

# 创建一个店员账户，并为该账户赋予以下权限：允许该账户对数据库bms中所有表执行插入、修改和查询操作
CREATE USER 'user2'@'localhost' IDENTIFIED BY 'user2pw'; -- 创建账户
GRANT INSERT,UPDATE,SELECT ON  bms.* TO 'user2'@'localhost'; --  为账户user2授权
