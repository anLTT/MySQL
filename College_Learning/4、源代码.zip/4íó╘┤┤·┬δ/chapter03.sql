/*3.1插入数据  */
/*3.1.1一次插入单条数据  */
# 向数据库ems中创建员工表emp
CREATE TABLE emp(
empno   INT PRIMARY KEY,
ename   VARCHAR(20) UNIQUE NOT NULL,
job     VARCHAR(20) NOT NULL,
mgr     INT ,
sal     DECIMAL(7,2),
comm    DECIMAL(7,2),
deptno  INT  
) ;

# 将表3-2中的员工数据插入到员工表emp中
INSERT INTO emp VALUES(9902,'赵六','分析员',9566,4000,NULL,20);

# 将表3-3中的员工数据插入到员工表emp中
INSERT INTO emp VALUES(9566,'李四','经理',9839,3995,NULL,20);


# 将表3-4中的员工数据插入到员工表emp中
INSERT INTO emp (empno,ename,job,sal,deptno)
VALUES(9839,'刘一','董事长',6000,10);

# 纵向查看数据表emp的创建语句
SHOW CREATE TABLE emp\G

# 将表3-5中的员工数据插入到员工表emp中
INSERT INTO emp
SET empno=9369,ename='张三',job='保洁',mgr=9902,sal=900.00,comm=NULL,deptno=20;


/*3.1.2一次插入多条数据  */
# 将表3-6中的员工数据插入到员工表emp中
INSERT INTO emp
VALUES
(9499,'孙七','销售',9698,2600,300,30),
(9521,'周八','销售',9698,2250,500,30),
(9654,'吴九','销售',9698,2250,1400,30),
(9982,'陈二','经理',9839,3450,NULL,10),
(9988,'王五','分析员',9566,4000,NULL,20),
(9844,'郑十','销售',9698,2500,0,30),
(9900,'萧十一','保洁',9698,1050,NULL,30);

/*3.2更新数据  */
# 将sal字段的值在原来的基础上增加200
UPDATE emp SET sal=sal+200 WHERE ename='张三';

# 将职位为保洁的员工涨薪300
 UPDATE emp SET sal=sal+300 WHERE job='保洁';

# 将所有员工涨薪500
UPDATE emp SET sal=sal+500;

/*3.3删除数据  */

# 删除员工表中孙七的数据
DELETE FROM emp WHERE ename='孙七';

# 删除员工表中职位为分析员的数据
DELETE FROM emp WHERE job='分析员';

# 将员工表中的所有数据全部删除
DELETE FROM emp;

/*多学一招：使用关键字TRUNCATE删除表中数据  */
# 创建tab_truncate表
CREATE TABLE tab_truncate(
    id INT(3) PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(4)
);

# 向tab_truncate表中添加5条数据
INSERT INTO tab_truncate(name)
VALUES('A'),('B'),('C'),('D'),('E');

# 使用TRUNCATE语句删除tab_truncate表中的所有数据
TRUNCATE TABLE tab_truncate;

# 在表tab_truncate 中，重新添加5条数据
INSERT INTO tab_truncate(name)VALUES('F'),('G'),('H'),('I'),('J');

# 使用DELETE语句删除tab_truncate表中的所有数据
 DELETE FROM tab_truncate;
 
# 向tab_truncate数据表中添加一条新数据
 INSERT INTO tab_truncate(name) VALUES('K');

/*3.4上机实践：图书表的数据操作  */

# 向图书表book中插入表3-1中的图书信息
INSERT INTO book (name,price,upload_time,state)
VALUES('Java基础入门（第3版）',59.00,CURRENT_TIMESTAMP,0);

# 向用户表user中批量插入表3-2中的用户信息
INSERT INTO user (name,state)
VALUES ('张三',0),('李四',0);

# 向图书表book中批量插入表3-3中的图书信息
INSERT INTO book (name,price,upload_time,state)
VALUES
('三国演义',69.00,CURRENT_TIMESTAMP,2),
('MySQL数据库入门',40.00,CURRENT_TIMESTAMP,0),
('JavaWeb程序开发入门',49.00,CURRENT_TIMESTAMP,0),
('西游记',59.00,CURRENT_TIMESTAMP,2),
('红楼梦',33.00,CURRENT_TIMESTAMP,2),
('水浒传',66.66,CURRENT_TIMESTAMP,2);

# 将图书表book中图书《西游记》状态修改为可借阅（state字段的值为0）
UPDATE book SET state=0 WHERE name='西游记';

# 将图书表book中《水浒传》的价格修改为66.00
UPDATE book SET price=66.00 WHERE name='水浒传';

# 将图书表book中所有的图书价格下调10%
UPDATE book SET price=price*0.9;

# 删除图书表中图书《红楼梦》
DELETE FROM book WHERE name='红楼梦';

# 为编号为1的用户借阅图书《MySQL数据库入门》
UPDATE book SET borrower_id=1, borrow_time=CURRENT_TIMESTAMP,state=1
 WHERE name='MySQL数据库入门';




