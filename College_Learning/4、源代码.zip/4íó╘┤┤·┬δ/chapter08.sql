/*8.1.1创建存储过程  */
# 编写存储过程，实现查询数据库ems的员工表emp中工资大于指定金额的员工信息
DELIMITER //
CREATE PROCEDURE pro_emp(IN tmp_money decimal(7,2))
BEGIN
  SELECT * FROM emp WHERE sal > tmp_money;
  END //
DELIMITER ;

/*8.1.2查看存储过程  */
# 显示数据库ems下存储过程pro_emp的状态信息
SHOW PROCEDURE STATUS LIKE 'pro_emp' \G

# 显示数据库ems下存储过程pro_emp的创建信息
SHOW CREATE PROCEDURE pro_emp \G

# 从information_schema.Routines表中查看存储过程pro_emp的信息
SELECT * FROM  information_schema.Routines WHERE ROUTINE_NAME='pro_emp' AND ROUTINE_TYPE='PROCEDURE'\G

/*8.1.3调用存储过程  */
# 调用数据库ems中的存储过程pro_emp，查询数据库ems的员工表emp中工资大于3000的员工信息
CALL pro_emp(3000);

/*8.1.4修改存储过程  */
# 将执行存储过程pro_emp的执行权限从定义者修改为调用者，并且添加注释信息
ALTER PROCEDURE pro_emp SQL SECURITY INVOKER COMMENT '统计工资大于指定金额的员工个数';
# 查询存储过程pro_emp的状态信息
SHOW PROCEDURE STATUS LIKE 'pro_emp'\G
/*8.1.5删除存储过程  */
# 删除数据库ems中的存储过程pro_emp
DROP PROCEDURE IF EXISTS pro_emp;

# 查询 information_schema数据库下Routines表中存储过程pro_emp的记录
SELECT * FROM  information_schema.Routines WHERE ROUTINE_NAME='pro_emp' AND ROUTINE_TYPE='PROCEDURE'\G

/*8.2.1创建存储函数  */
# 编写根据输入员工的姓名返回对应工资信息的存储函数
DELIMITER &&
CREATE FUNCTION func_emp(emp_name VARCHAR(20))
RETURNS  decimal(7,2)
BEGIN
  RETURN (SELECT sal FROM emp WHERE ename=emp_name );
END &&
DELIMITER ;

/*小提示  */
# 设置自定义函数的配置
SET GLOBAL log_bin_trust_function_creators = 1; 

/*8.2.2查看存储函数  */
# 查看数据库ems中，存储函数func_emp的状态信息
SHOW FUNCTION STATUS LIKE 'func_emp' \G

/*8.2.3调用存储函数  */
# 调用ems中存储函数func_emp
SELECT func_emp('刘一');

/*8.2.4删除存储函数  */
# 删除数据库ems中的存储函数func_emp
DROP FUNCTION IF EXISTS func_emp;

# 查询 information_schema数据库下Routines表中存储函数func_emp的记录
SELECT * FROM  information_schema.Routines WHERE ROUTINE_NAME='func_emp' AND ROUTINE_TYPE='FUNCTION'\G

/*8.3.1系统变量  */
# 显示变量名以auto_inc开头的所有系统变量
SHOW  VARIABLES LIKE 'auto_inc%';

# 将系统变量auto_increment_offset的值修改为2
SET auto_increment_offset = 2;

# 在当前客户端查看系统变量auto_increment_offset的值
SHOW  VARIABLES WHERE Variable_name= 'auto_increment_offset';

# 在新打开的客户端中查看系统变量auto_increment_offset的值
SHOW  VARIABLES WHERE Variable_name= 'auto_increment_offset';

# 将系统变量auto_increment_offset的值修改为5
SET GLOBAL auto_increment_offset = 5;

/*8.3.2用户变量  */
# 使用SET语句完成用户变量赋值
SET @ename='刘';
 
# 在SELECT语句中使用赋值符号:=完成用户变量赋值。 
SELECT @sal:= sal FROM emp WHERE ename='刘一';

# 使用SELECT…INTO语句完成用户变量赋值
SELECT empno,ename,sal FROM emp LIMIT 1 INTO @e_no,@e_name,@e_sal;

# 查询出用户变量的值
SELECT @ename,@sal,@e_no,@e_name,@e_sal;

/*8.3.3局部变量  */
# 在存储函数中创建局部变量，并在函数中返回该局部变量
DELIMITER &&

CREATE FUNCTION func_var()
RETURNS INT
BEGIN
DECLARE sal INT DEFAULT 1500;
RETURN sal;
END &&

DELIMITER ;

# 调用存储函数func_var()
SELECT func_var();

# 查询局部变量sal
SELECT sal;

/*8.4.1判断语句  */
# 根据输入的员工姓名返回对应的员工信息，如果输入为空，则显示输入的值为空；如输入的员工姓名在员工表中不存在，则显示员工不存在。将这个需求编写成存储过程
DELIMITER &&
CREATE PROCEDURE proc_isnull(IN e_name VARCHAR(20))
BEGIN
 DECLARE ecount INT DEFAULT 0;
 SELECT COUNT(*) INTO ecount FROM emp WHERE ename=e_name;
 IF e_name IS NULL
         THEN SELECT '输入的值为空';
 ELSEIF ecount=0
         THEN SELECT '员工不存在';
 ELSE
         SELECT * FROM emp WHERE ename=e_name;
 END IF;
END &&

DELIMITER ;

# 传入不同的参数，调用存储过程proc_isnull
CALL proc_isnull(NULL);
CALL proc_isnull('刘大');
CALL proc_isnull('刘一');

# 根据输入的员工工资返回对应的工资等级，如果工资大于等于5000，则返回高薪资；如果小于5000并且大于等于4000则返回中等薪资；如果小于4000并且大于等于2000则返回低薪资；其他金额则返回不合理薪资。将这个需求编写成存储函数
DELIMITER &&

CREATE FUNCTION func_level(esal DECIMAL(7,2))
RETURNS VARCHAR(20)
BEGIN
 CASE
 WHEN esal>=5000 THEN RETURN '高薪资';
 WHEN esal >=4000 THEN RETURN '中等薪资';
 WHEN esal >=2000 THEN RETURN'低薪资';
 ELSE RETURN'不合理薪资';
 END CASE;
END &&

DELIMITER ;

/*8.4.2循环语句  */
# 在存储过程中实现0~9之间整数的累加计算
DELIMITER &&

CREATE PROCEDURE proc_sum()
BEGIN
 DECLARE i,sum INT DEFAULT 0;
 sign: LOOP
         IF i >=10 THEN
                 SELECT i,sum;
                 LEAVE sign;
         ELSE
                 SET sum=sum+i;
                 SET i=i+1;
         END IF;
 END LOOP sign;
END &&

DELIMITER ;

# 调用存储过程proc_sum
CALL proc_sum();

# 在存储过程内实现0~10之间奇数的累加计算
DELIMITER &&

CREATE PROCEDURE proc_odd()
BEGIN
 DECLARE i,sum INT DEFAULT 0;
 sign: REPEAT
         IF i%2 != 0 THEN SET sum=sum+i;
         END IF;
         SET i=i+1;
 UNTIL i>10
 END REPEAT sign;
 SELECT i,sum;
END &&

DELIMITER ;

# 调用存储过程proc_odd
CALL proc_odd();

CREATE PROCEDURE proc_even()
BEGIN
 DECLARE i,sum INT DEFAULT 0;
 WHILE i<=10 DO
         IF i % 2=0
                 THEN SET sum=sum+i;
         END IF;
         SET i=i+1;
 END WHILE;
 SELECT i,sum;
END &&

DELIMITER ;


# 使用WHILE语句在存储过程内实现0~10之间偶数的累加计算
DELIMITER &&

CREATE PROCEDURE proc_even()
BEGIN
 DECLARE i,sum INT DEFAULT 0;
 WHILE i<=10 DO
         IF i % 2=0
                 THEN SET sum=sum+i;
         END IF;
         SET i=i+1;
 END WHILE;
 SELECT i,sum;
END &&

DELIMITER ;

# 调用存储过程proc_even
CALL proc_even();

/*8.4.3跳转语句  */
# 通过存储函数计算5以下的正偶数的累加
DELIMITER &&

CREATE PROCEDURE proc_jump()
BEGIN
 DECLARE num INT DEFAULT 0;
 my_loop: LOOP
         SET num=num+2;
         IF num <5
                 THEN ITERATE my_loop;
         ELSE SELECT num;LEAVE my_loop;
         END IF;
END LOOP my_loop;
END &&

DELIMITER ;

# 调用存储过程proc_jump
CALL proc_jump();

/*8.5.1自定义错误名称  */
# 为23000对应的SQLSTATE类型的错误代码声明一个名称
DELIMITER &&

CREATE PROCEDURE proc_err()
BEGIN
 DECLARE duplicate_entry CONDITION FOR SQLSTATE '23000';
END &&

DELIMITER ;

/*8.5.2自定义错误处理程序 */
# 创建错误处理程序，处理2300对应的SQLSTATE类型的错误
DELIMITER &&

CREATE PROCEDURE proc_handler_err()
BEGIN
 DECLARE CONTINUE HANDLER FOR SQLSTATE '23000'
 SET @num=1;
 INSERT INTO emp VALUES(9944,'白龙马','人事',9982,1000,500,40);
 SET @num=2;
 INSERT INTO emp VALUES(9944,'白龙马','人事',9982,1000,500,40);
 SET @num=3;
END &&

DELIMITER ;

# 调用存储过程proc_handler_err
 CALL proc_handler_err();
 
/*8.6.2使用游标检索数据 */
# 创建用来存放结果数据的数据表emp_comm
CREATE TABLE emp_comm(
	empno   INT PRIMARY KEY,
	ename   VARCHAR(20) UNIQUE,
	job     VARCHAR(20),
	mgr     INT,
	sal     DECIMAL(7,2),
	comm    DECIMAL(7,2),
	deptno  INT
);

# 创建存储过程，在存储过程中将奖金为NULL的员工信息添加到数据表emp_comm
DELIMITER &&

CREATE PROCEDURE proc_emp_comm()
BEGIN
DECLARE mark INT DEFAULT 0; -- mark:游标结束循环的标识
DECLARE emp_no INT ; -- emp_no:存储员工表empno字段的值
DECLARE emp_name VARCHAR(20); -- emp_name:存储员工表ename字段的值
DECLARE emp_job VARCHAR(20); -- emp_job:存储员工表job字段的值
DECLARE emp_mgr INT; -- emp_mgr:存储员工表mgr字段的值
DECLARE emp_sal decimal(7,2); -- emp_sal:存储员工表sal字段的值
DECLARE emp_comm decimal(7,2); -- emp_comm:存储员工表comm字段的值
DECLARE emp_deptno INT; -- emp_deptno:存储员工表deptno字段的值
# 定义游标
DECLARE cur CURSOR FOR SELECT * FROM emp WHERE comm IS NULL;
# 定义错误处理程序
DECLARE CONTINUE HANDLER FOR SQLSTATE '02000'
  SET mark=1;
#打开游标
OPEN cur;
REPEAT
 # 通过游标获取结果集的记录
 FETCH cur INTO emp_no,emp_name,emp_job,emp_mgr,emp_sal,emp_comm,emp_deptno;
 IF mark!=1 THEN
         INSERT INTO emp_comm(empno,ename,job,mgr,sal,comm,deptno)
         VALUES(emp_no,emp_name,emp_job,emp_mgr,emp_sal,emp_comm,emp_deptno);
  END IF;
UNTIL mark=1 END REPEAT;
 # 关闭游标
CLOSE cur;
END &&
DELIMITER ;

# 调用存储过程proc_emp_comm
CALL proc_emp_comm();



/*8.7.1触发器概述  */

/*8.7.2触发器的基本操作  */
# 创建一张新的数据表，用于存放被删除的员工信息
CREATE TABLE emp_del(
	empno   INT PRIMARY KEY,
	ename   VARCHAR(20) UNIQUE,
	job     VARCHAR(20),
	mgr     INT,
	sal     DECIMAL(7,2),
	comm    DECIMAL(7,2),
	deptno  INT
);

# 在员工表emp中创建触发器，当删除员工表的数据后，触发该触发器，并且在触发器的触发程序中将被删除的员工添加到数据表emp_del中
CREATE TRIGGER trig_emp
AFTER DELETE ON emp FOR EACH ROW
INSERT INTO emp_del(empno,ename,job,mgr,sal,comm,deptno)
VALUES(old.empno,old.ename,old.job,old.mgr,old.sal,old.comm,old.deptno);

# 查看当前数据库中已经存在的触发器
SHOW TRIGGERS\G

# 查询触发器trig_emp的信息
SELECT * FROM information_schema.triggers WHERE trigger_name= 'trig_emp' \G

# 删除ems中的触发器trig_emp
DROP TRIGGER IF EXISTS ems.trig_emp; 
/*8.8上机实践：数据库编程实战  */

# （1）创建一个存储过程proc_1，执行后获取图书的名称、价格和借阅状态，如果是未借阅的状态，则显示未借阅；如果是已借阅的状态，则显示借阅人。创建完存储过程proc_1后，执行该存储过程查看效果
DELIMITER //
CREATE PROCEDURE proc_1()
BEGIN
 SELECT b.name,b.price,IF(borrower_id IS NULL,'未借阅',u.name) 借阅人
 FROM book b LEFT JOIN user u ON b.borrower_id=u.id;
END //
DELIMITER ;

CALL proc_1(); -- 调用存储过程proc_1

# （2）创建一个存储过程proc_2，执行后获取所有可借阅的图书信息，图书信息只需显示图书名称、图书价格和上架时间。创建完存储过程proc_2后，执行该存储过程查看效果
DELIMITER //
CREATE PROCEDURE proc_2()
BEGIN
 SELECT name,price,upload_time   FROM book WHERE state=0;
END //
DELIMITER ;

CALL proc_2(); -- 调用存储过程proc_2

# （3）店员想要创建一个存储函数func_1，执行时输入用户名称，显示用户当前借阅中的图书名称。创建完存储函数func_1后，执行该存储函数查看效果。
DELIMITER //
CREATE FUNCTION func_1(uname varchar(20))
 RETURNS  varchar(20)
 BEGIN
 RETURN (SELECT b.name FROM user u,book b WHERE u.id=b.borrower_id AND u.name=uname);
END //
DELIMITER ; 

SELECT func_1('张三'); -- 调用存储函数func_1

# （4）店员想要创建一个存储函数func_2，执行时输入图书名称，显示图书当前的价格档位；如果价格小于等于40，显示“平民价格”；如果价格大于40并且小于等于60，则显示“主流价格”；如果价格大于60，则显示“高价格”。创建完存储函数func_2后，执行该存储函数查看效果。
DELIMITER //
CREATE FUNCTION func_2(bname varchar(20))
 RETURNS  varchar(20)
 BEGIN
   DECLARE blevel VARCHAR(10);
   DECLARE bprice decimal(6, 2);
   SELECT price INTO bprice FROM book WHERE name=bname;
   IF bprice>60
       THEN SET blevel='高价格';
   ELSEIF bprice<=60 AND bprice>40
       THEN SET blevel='主流价格';
   ELSEIF empsal<=40
       THEN SET blevel='平民价格';
   END IF;
  RETURN blevel;
  END //
DELIMITER ;

SELECT func_2('西游记'); -- 调用存储函数func_2

# （5）查看当前数据库中存储过程proc_1和存储函数func_1的信息。
SHOW PROCEDURE STATUS LIKE 'proc_1'\G  -- 查看存储过程proc_1
SHOW FUNCTION STATUS LIKE 'func_1' \G  -- 查看存储函数func_1

# （6）删除存储过程proc_1和存储函数func_1
DROP PROCEDURE IF EXISTS proc_1;  -- 删除存储过程proc_1
DROP FUNCTION IF EXISTS func_1;  -- 删除存储函数func_1

# （7）创建一个触发器trig_book，在借阅记录表中插入数据时，自动修改图书表中借阅相关的信息
CREATE TRIGGER trig_book
AFTER INSERT ON record FOR EACH ROW
UPDATE book SET borrower_id =NULL,borrow_time=NULL,state=0
WHERE book.id=NEW.book_id;

# （8）查看触发器trig_book
SELECT * FROM information_schema.triggers WHERE trigger_name= 'trig_book' \G



