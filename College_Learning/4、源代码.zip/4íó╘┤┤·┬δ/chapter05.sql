/*5.1多表查询  */
/*5.1.1交叉连接查询  */
# 创建一个部门表dept
CREATE TABLE dept(
	deptno	INT PRIMARY KEY,
	dname	VARCHAR(20) UNIQUE
);
# 插入部门数据
INSERT INTO dept 
VALUES
(10, '总裁办'),
(20, '研究院'),
(30, '销售部'),
(40, '运营部');

# 员工表和部门表进行交叉连接查询
SELECT * FROM emp,dept;

/*5.1.2内连接查询  */
# 查询已经分配了部门（部门号不为NULL）的员工的信息
SELECT ename,dname FROM emp e JOIN dept d ON e.deptno=d.deptno;

# 查询员工王五所在部门的所有员工信息
SELECT e1.* FROM emp e1 JOIN emp e2 ON e1.deptno=e2.deptno WHERE e2.ename='王五';

/*5.1.3外连接查询 */
# 查询所有部门名称及部门对应员工的姓名
SELECT d.dname,e.ename FROM dept d LEFT JOIN emp e ON e.deptno=d.deptno;

# 查询所有员工姓名及对应部门的名称，没有分配部门的员工也需要查询出来
SELECT d.dname,e.ename FROM dept d RIGHT JOIN emp e ON e.deptno=d.deptno;

/*5.1.4复合条件连接查询 */
# 查询所有员工信息，员工信息包含员工所在部门的名称，并且按员工的工资降序排序
SELECT e.*,d.dname FROM emp e LEFT JOIN dept d ON e.deptno=d.deptno ORDER BY e.sal DESC;

/*5.2.1IN关键字结合子查询 */
# 查询工资大于2900的员工所属部门
SELECT * FROM dept WHERE deptno IN(SELECT deptno FROM emp WHERE sal>2900);

# 查询工资小于2900的员工所在的部门信息
SELECT * FROM dept WHERE deptno NOT IN(SELECT deptno FROM emp WHERE sal>2900);

/*5.2.2EXISTS关键字结合子查询 */
# 查询工资大于2900的员工所在的部门信息
SELECT * FROM dept  WHERE EXISTS (SELECT * FROM emp WHERE emp.deptno=dept.deptno AND emp.sal>2900);

/*5.2.3ANY关键字结合子查询 */
# 查询部门编号为10的员工信息，要求查询到的员工信息中，工资都高于部门编号为20的部门中的最低工资
SELECT * FROM emp WHERE deptno=10 AND sal>ANY(SELECT sal FROM emp WHERE deptno=20);

/*5.2.4ALL关键字结合子查询 */
# 查询部门编号为10的员工信息，要求查询到的员工信息中，工资都高于部门编号为20的部门中的最高工资
SELECT * FROM emp WHERE deptno=10 AND sal>ALL(SELECT sal FROM emp  WHERE deptno=20);

/*5.2.5比较运算符结合子查询 */
# 查询与王五职位相同的员工信息
SELECT * FROM emp WHERE job=(SELECT job FROM emp WHERE ename='王五') AND ename !='王五';

/*5.3.1添加外键约束 */
# 给员工表emp添加外键约束
 ALTER TABLE emp ADD CONSTRAINT fk_deptno FOREIGN KEY(deptno) REFERENCES dept(deptno);
 
/*5.3.2操作关联表 */
# 主表dept添加数据
INSERT INTO dept VALUES(50, '人力资源部');
# 在往员工表emp中添加数据
INSERT INTO emp VALUES(9966,'八戒','运营专员',9839,3000,2000,40);
INSERT INTO emp VALUES(9999,'悟空','人事专员',9982,3000,NULL,50);

# 查询人力资源部有哪些员工
SELECT e.*,d.dname FROM emp e,dept d WHERE e.deptno=d.deptno AND d.dname='人力资源部';

# 删除从表emp中属于人力资源部的员工信息
DELETE FROM emp WHERE deptno=(SELECT deptno FROM dept WHERE dname='人力资源部');

# 查询属于人力资源部的员工信息
SELECT e.*,d.dname FROM emp e,dept d WHERE e.deptno=d.deptno AND d.dname='人力资源部';

# 删除主表dept中的数据
DELETE FROM  dept WHERE dname='人力资源部';

/*5.3.3删除外键约束 */
# 将员工表emp中的外键约束删除
ALTER TABLE emp DROP FOREIGN KEY fk_deptno;





/*5.4上机实践：图书管理系统的多表操作  */
# 查询张三当前借阅的图书信息，图书信息只需显示借阅人编号、借阅人名称、图书名称和借阅时间
SELECT u.id,u.name borrower,b.name bookname,b.borrow_time FROM book b,user u
 WHERE b.borrower_id=u.id AND u.name='张三';

# 查询价格比《西游记》的价格高的图书信息，图书信息只需显示图书名称和图书价格
SELECT name,price FROM book WHERE price>(SELECT price FROM book WHERE name='西游记');

# 查询价格比所有图书的平均价格还低的图书信息，图书信息只需显示图书名称和图书价格
SELECT name,price FROM book WHERE price<(SELECT AVG(price) FROM book);

# 查询图书状态和《三国演义》相同的图书信息，图书信息只需显示图书名称、图书价格和状态
SELECT name,price,state FROM book WHERE state=(SELECT state FROM book WHERE name='三国演义');

# 查询已借阅图书中，价格比任意未借阅的图书价格还低的图书信息，图书信息只需显示图书名称、图书价格和状态
SELECT name,price,state FROM book WHERE state=1 AND price<ANY(SELECT price FROM book WHERE state=0);

# 查询价格比任意已借阅的图书价格还高的图书信息，图书信息只需显示图书名称、图书价格和状态
SELECT name,price,state FROM book WHERE price>ALL(SELECT price FROM book WHERE state=1);

# 对图书表中的借阅者编号添加外键约束
 ALTER TABLE book ADD CONSTRAINT FK_ID FOREIGN KEY(borrower_id) REFERENCES user (id);
