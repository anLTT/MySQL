/*4.2简单查询  */
/*4.2.1查询所有字段  */
# 向员工表emp中插入数据
INSERT INTO emp 
VALUES
(9839,'刘一','董事长',NULL,6000,NULL,10),
(9982,'陈二','经理',9839,3450,NULL,10),
(9369,'张三','保洁',9902,900,NULL,20),
(9566,'李四','经理',9839,3995,NULL,20),
(9988,'王五','分析员',9566,4000,NULL,20),
(9902,'赵六','分析员',9566,4000,NULL,20),
(9499,'孙七','销售',9698,2600,300,30),
(9521,'周八','销售',9698,2250,500,30),
(9654,'吴九','销售',9698,2250,1400,30),
(9844,'郑十','销售',9698,2500,0,30),
(9900,'萧十一','保洁',9698,1050,NULL,30);

# 使用SELECT语句列出所有字段名称的方式查询员工表中的所有数据
SELECT empno,ename,job,mgr,sal,comm,deptno FROM emp;

# 将ename字段放在查询列表的最后一列
SELECT empno,job,mgr,sal,comm,deptno,ename FROM emp;

# 使用通配符*查询员工表emp中的所有记录
SELECT * from emp;

/*4.2.2查询指定字段  */
# 查询员工表emp中员工编号和员工名称
SELECT empno,ename FROM emp;

/*4.2.3查询去重数据  */
# 查询员工表emp中所有员工所属的部门编号
SELECT DISTINCT deptno FROM emp;

/*多学一招：DISTINCT关键字作用多个字段 */
# 查询数据表emp中的字段ename、字段job和字段deptno不重复的数据
SELECT DISTINCT ename,job,deptno FROM emp;

# 使用DISTINCT仅作用job字段和deptno字段的记录
SELECT DISTINCT job,deptno FROM emp;

/*4.3条件查询  */
/*4.3.1带比较运算符的查询  */
# 查询员工表emp中员工张三的信息
 SELECT * FROM emp WHERE ename='张三';
 
# 查询员工表中，所属部门编号不是30的员工信息
SELECT * FROM emp WHERE deptno<>30;

# 查询员工表中，工资小于1000元的员工信息
SELECT * FROM emp WHERE sal<1000;

# 查询员工表中，基本工资大于等于3000元的员工信息
SELECT * FROM emp WHERE sal>=3000;

# 查询员工表中，所属部门编号为10或者20的员工信息
SELECT * FROM emp WHERE deptno IN(10,20);

# 查询员工表中，直属上级编号为NULL的员工信息，
 SELECT * FROM emp WHERE mgr IS NULL;
 
# 查询员工表中，姓名以“一”结尾的员工信息
SELECT * FROM emp WHERE ename LIKE '%一';

# 查询员工表中，姓名以“萧”开头以“一”结尾的员工信息
SELECT * FROM emp WHERE ename LIKE '萧%一';

# 查询员工表中，姓名包含字符“十”的员工信息
 SELECT * FROM emp WHERE ename LIKE '%十%';
 
# 查询员工表中，姓名长度为3，并且以字符“一”结尾的员工信息
SELECT * FROM emp WHERE ename LIKE '__一'; 
 
 /*多学一招：字符%和_的转义 */
# 在emp表中添加姓名包含%的员工信息
INSERT INTO emp VALUES(9936,'张%一','保洁',9982,1200,NULL,NULL); 

# 查询emp表中，姓名包含%的员工信息
SELECT * FROM emp WHERE ename LIKE '%\%%';
 
/*4.3.2带逻辑运算符的查询  */
# 查询员工表中，部门编号不是10和30的员工信息
SELECT * FROM emp WHERE deptno NOT IN(10,30);

# 查询员工表中职位为经理，并且所属部门编号为20的员工信息
SELECT * FROM emp WHERE job='经理' AND deptno=20;

# 查询员工表中，员工编号为9900至9935的员工信息
SELECT * FROM emp WHERE empno BETWEEN 9900 AND 9935;

# 查询员工表中，员工编号不是9500至9900的员工信息
SELECT * FROM emp WHERE empno NOT BETWEEN 9500 AND 9900;

#查询员工表中，员工职位为经理或者所属部门编号为10的员工信息
SELECT * FROM emp WHERE job='经理' OR deptno=10;

/*多学一招：OR和AND关键字一起使用的情况  */
# 查询emp表中，员工姓名为刘一，或者员工姓名为李四并且部门编号为30的员工信息
SELECT * FROM emp WHERE ename='刘一' or ename='李四' AND deptno=30;

/*4.4高级查询  */
/*4.4.1聚合函数  */
# 查询员工表中有多少个员工的记录
SELECT COUNT(*) FROM emp;

# 查询员工表中，奖金不为NULL的员工个数
SELECT COUNT(COMM) FROM emp;

# 查询员工表中员工奖金的总和
SELECT SUM(COMM) FROM emp;

# 查询员工表中员工的平均奖金
SELECT AVG(COMM) FROM emp;

# 查询所有员工的平均奖金
SELECT AVG(IFNULL(COMM,0)) FROM emp;

# 查询员工表中最高的工资
SELECT MAX(sal) FROM emp;

# 查询员工表中最低的工资
SELECT MIN(sal) FROM emp;

/*4.4.2分组查询  */
# 查询员工表的部门编号有哪几种
SELECT deptno FROM emp GROUP BY deptno;

# 统计员工表各部门的薪资总和或平均薪资
SELECT deptno,AVG(sal),SUM(sal) FROM emp GROUP BY deptno;

# 查询员工表中平均工资小于3000的部门编号及这些部门的平均工资
SELECT deptno,AVG(sal) FROM emp GROUP BY deptno HAVING AVG(sal)<3000;
 
/*4.4.3排序查询  */
# 查询员工表中，部门编号为30的员工信息
SELECT * from emp WHERE deptno=30 ORDER BY sal;

# 查询员工表中，部门编号为30的员工信息，查询出的结果根据工资降序排列
SELECT * from emp WHERE deptno=30 ORDER BY sal DESC;

# 查询员工表中，部门编号为30的员工信息，并且根据奖金升序排序
SELECT * from emp WHERE deptno=30 ORDER BY comm;

# 查询员工表中，部门编号为30的所有记录，查询出的记录先按职位升序排序，职位相同的记录再按奖金降序排序
SELECT * from emp WHERE deptno=30 ORDER BY job,empno DESC;
 
/*4.4.4限量查询  */
# 查询员工表中，工资最高的前5名的员工信息
SELECT * FROM emp ORDER BY sal DESC LIMIT 5;
 
# 查询员工表中，工资前2~5名的员工信息 
SELECT * FROM emp ORDER BY sal DESC LIMIT 1,4;
 
/*4.4.5内置函数  */
# 查询员工信息时，将部门编号为30的员工姓名、员工职位及员工所属部门编号的信息
SELECT CONCAT(ename,'_',job,'_',deptno) FROM emp WHERE deptno=30;
# 查询员工信息时，将部门编号为30的员工姓名、员工奖金及员工部门编号的信息在一列中显示
SELECT CONCAT(ename,'_',comm,'_',deptno) FROM emp WHERE deptno=30;

# 查询员工表中，部门编号为30的员工姓名、员工奖金及员工部门编号的信息；如果奖金为NULL，返回“无奖金”
SELECT ename,IF(ISNULL(comm),'无奖金',comm),deptno FROM emp WHERE deptno=30;

/*4.5设置别名  */
/*4.5.1为数据表设置别名  */
# 查询员工信息时，为emp数据表起一个别名e，并且使用别名e查询部门编号为30的员工信息
SELECT * FROM emp e WHERE e.deptno=30;
/*4.5.2为字段设置别名  */
# 查询员工表中，部门编号为30的员工姓名、员工奖金及员工部门编号的信息，查询结果返回时，将字段ename的名称设置别名“姓名”，字段comm的名称设置别名“奖金”，字段deptno的名称设置别名“部门编号”
SELECT ename AS '姓名', comm '奖金',deptno '部门编号' FROM emp WHERE deptno=30;

/*4.6上机实践：图书管理系统的单表查询  */
# 查询只显示图书名称和上架时间的可借阅图书的清单
SELECT name,upload_time FROM book WHERE state=0;

# 根据图书名称升序排序的前5条图书的信息，查询出的结果只需显示图书的名称、价格和状态
SELECT name,price,state FROM book ORDER BY name ASC LIMIT 5;

# 查询价格大于50的图书的名称
SELECT name, price FROM book WHERE price>50;

# 查询价格大于等于30并且小于等于50的图书的名称和价格
SELECT name, price FROM book WHERE price BETWEEN 30 AND 50;

# 查询已借阅图书的图书名称、借阅人编号和借阅时间
SELECT name,borrower_id,borrow_time FROM book WHERE state=1;

# 查询包含“Java”的所有图书名称
SELECT name FROM book WHERE name LIKE '%Java%';

# 查询以“入门”结尾的所有图书名称
SELECT name FROM book WHERE name LIKE '%入门';

# 查询“西游记”或者“红楼梦”的图书信息，只需要显示图书名称和价格
SELECT name,price FROM book WHERE name IN('西游记','红楼梦') ;


