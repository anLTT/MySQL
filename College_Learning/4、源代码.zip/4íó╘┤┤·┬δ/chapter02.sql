/* 2.1 数据库操作 */
/* 2.1.1创建数据库 */
# 创建一个名称为itcast，字符集为utf8mb4的数据库
CREATE DATABASE IF NOT EXISTS itcast CHARACTER SET utf8mb4;

/* 2.1.2查看数据库 */

# 查看数据库系统中已经创建的数据库
SHOW DATABASES;

#查看数据库itcast的创建语句
SHOW CREATE DATABASE itcast;

/* 2.1.3选择数据库 */

# 选择数据库itcast
USE itcast;

#查看当前选择的是哪个数据库
SELECT DATABASE();

/* 2.1.4修改数据库特征 */

# 将数据库itcast的字符集修改为gbk
ALTER DATABASE itcast DEFAULT CHARACTER SET gbk;

# 查看数据库itcast的创建语句
SHOW CREATE DATABASE itcast;

/* 2.1.5删除数据库 */

# 删除数据库itcast
DROP DATABASE IF EXISTS itcast;

# 查看数据库系统中已经创建的数据库
SHOW DATABASES;

/* 2.3数据表的基本操作 */
/* 2.3.1创建数据表 */
# 创建一个名称为ems，字符集为utf8mb4的数据库
CREATE DATABASE IF NOT EXISTS ems  CHARACTER SET utf8mb4;

# 选择数据库ems
USE ems

#创建数据表tb_dept
CREATE TABLE tb_dept(deptno INT,dname VARCHAR(14),loc VARCHAR(13));

/* 2.3.2查看数据表 */
# 查看当前数据库中所有的数据表
SHOW  TABLES;

# 显示创建数据表tb_dept的语句
SHOW CREATE TABLE tb_dept;

# 使用DESC语句查看数据表tb_dept的表结构信息
DESC tb_dept;

/* 多学一招：纵向结构显示结果 */
# 纵向显示数据表tb_dept的表结构
SHOW CREATE TABLE tb_dept\G

/*2.3.3修改数据表 */
# 使用SHOW TABLES语句查看数据库中的所有数据表
SHOW TABLES;
# 数据表tb_dept的名称修改为dept
ALTER TABLE tb_dept RENAME TO dept;

# 修改数据表dept的字符集为gbk
ALTER TABLE dept CHARACTER SET=gbk;

# 将部门表dept中的字段名loc改为local_name
ALTER TABLE dept RENAME COLUMN loc TO local_name ;

# 将部门表dept中字段dname 的数据类型修改为CHAR(16)
ALTER TABLE dept MODIFY dname CHAR(16);

# 将部门表dept中字段local_name的位置修改为数据表的第一个字段
ALTER TABLE dept CHANGE local_name local_name CHAR(20) FIRST;

# 将部门表dept中字段deptno修改到字段dname后面
ALTER TABLE dept MODIFY deptno INT AFTER dname;

# 在数据表dept的第一列添加一个INT类型的字段id
ALTER TABLE dept ADD id INT FIRST;

# 删除数据表dept的id字段
ALTER TABLE dept DROP id;

/*2.3.4删除数据表 */
# 删除数据库itcast
DROP TABLE IF EXISTS dept;

/*2.4表的约束 */

/*2.4.1非空约束 */
# 创建数据表tb_dept01时为字段local设置非空约束
CREATE TABLE tb_dept01(
	deptno INT,
	dname VARCHAR(14),
	local VARCHAR(13) NOT NULL
);

# 修改数据表tb_dept01时为字段dname设置非空约束
ALTER TABLE tb_dept01 MODIFY dname VARCHAR(14) NOT NULL;

# 删除tb_dept01数据表中dname字段的非空约束
ALTER TABLE tb_dept01 CHANGE COLUMN dname dname varchar(14);

/*2.4.2唯一约束 */
# 创建数据表tb_emp01时为字段empno设置唯一约束,以及为字段deptname和ename设置唯一约束
CREATE TABLE tb_emp01(
	deptname VARCHAR(16) ,
	empno   INT  UNIQUE,
	ename   VARCHAR(16) ,
	job     VARCHAR(16) NOT NULL,
	email   VARCHAR(30),
	UNIQUE (deptname,ename)
) ;

# 为数据表tb_emp01中的email字段添加唯一约束
ALTER TABLE tb_emp01 ADD  UNIQUE(email);

# 将数据表tb_emp01中的empno字段唯一约束删除
ALTER TABLE tb_emp01 DROP index empno;

/*2.4.3主键约束 */

# 创建数据表tb_dept02时，为字段id设置主键约束
CREATE TABLE tb_dept02(
	id INT PRIMARY KEY,
	dname VARCHAR(14) UNIQUE,
	local VARCHAR(13) NOT NULL
);

# 为数据表tb_dept01中的deptno字段添加主键约束
ALTER TABLE tb_dept01 ADD PRIMARY KEY(deptno);

# 删除数据表tb_dept01中的主键约束
ALTER TABLE tb_dept01 DROP PRIMARY KEY;

/*2.4.4默认值约束 */
# 创建数据表tb_emp02时，为字段status设置默认值约束
 CREATE TABLE tb_emp02(
	 id INT PRIMARY KEY,
	 ename VARCHAR(16) UNIQUE,
	 sal DECIMAL(7,2),
	 status VARCHAR(13) DEFAULT 1
 );
 
 # 字段sal添加默认值约束
 ALTER TABLE tb_emp02 MODIFY sal DECIMAL(7,2) DEFAULT 0.00;
 
 # 删除字段sal的默认值约束
 ALTER TABLE tb_emp02 CHANGE sal sal DECIMAL(7,2);
 
 /*2.5字段自动增长 */
 # 创建数据表tb_emp03时，为主键字段empno设置自动增长
CREATE TABLE tb_emp03(
	empno INT PRIMARY KEY AUTO_INCREMENT,
	deptname VARCHAR(14) NOT NULL,
	job VARCHAR(13)
);

 /*2.6上机实践：图书管理系统的数据库及相关数据表的创建 */
 
# 创建字符集为utf8mb4的数据库bms
 CREATE DATABASE bms CHARACTER SET utf8mb4;
 
# 选择数据库bms
 USE bms
 
# 创建数据表user
CREATE TABLE user  (
	id INT PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(20) NOT NULL UNIQUE,
	state CHAR(1) NOT NULL DEFAULT 0
);

# 创建数据表book
CREATE TABLE book  (
	id INT  PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(20) NOT NULL UNIQUE,
	price DECIMAL(6, 2)  NOT NULL,
	upload_time DATETIME NOT NULL,
	borrower_id INT ,
	borrow_time DATETIME,
	state CHAR(1) NOT NULL DEFAULT 0
);

# 创建数据表record
CREATE TABLE record  (
	id INT  PRIMARY KEY AUTO_INCREMENT,
	book_id INT NOT NULL,
	borrower_id INT NOT NULL,
	borrow_time DATETIME NOT NULL,
	remand_time DATETIME NOT NULL
);
 
# 查看数据表book的表结构信息
DESC book;
 
 
 
 
 
 



